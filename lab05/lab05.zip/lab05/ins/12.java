class Principal {
    public static void F12() {
        int x = 5;
        {
            int x = 10;
            x = x + 1;
        }
    }
}