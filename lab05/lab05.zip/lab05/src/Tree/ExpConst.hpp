#ifndef _EXP_CONST_HPP_
#define _EXP_CONST_HPP_
#include "Exp.hpp"
#include "../src-gram-java/ExpressaoValor.hpp"

class ExpConst : public Exp {
public:
  int valor;
  ExpConst();
  void imprime() const;
  static ExpConst* gera_Exp_Const(ExpressaoValor* e);
};

#endif
